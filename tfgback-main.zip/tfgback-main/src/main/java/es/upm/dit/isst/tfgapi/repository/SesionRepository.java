package main.java.es.upm.dit.isst.tfgapi.repository;
import org.springframework.data.repository.CrudRepository;

public interface SesionRepository extends CrudRepository<Sesion, Long> {
}
